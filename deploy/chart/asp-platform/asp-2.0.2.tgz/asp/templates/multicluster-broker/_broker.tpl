{{/*
Define broker multicluster enabled
*/}}
{{- define "pulsar.broker.multicluster.enabled" -}}
{{- if .Values.broker.multicluster.enabled -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Define broker multicluster replicas placement
*/}}
{{- define "pulsar.broker.multicluster.replicas.placement" -}}
{{- if .Values.broker.multicluster.enabled -}}
placement:
  {{- if .Values.broker.multicluster.clusterAffinity }}
  clusterAffinity:
    {{- if .Values.broker.multicluster.clusterAffinity.clusters }}
    clusterNames:
    {{ .Values.broker.multicluster.clusterAffinity.clusters | toYaml | nindent 4 }}
    {{- end }}
    {{- if .Values.broker.multicluster.clusterAffinity.excludeClusters }}
    excludeClusters:
    {{ .Values.broker.multicluster.clusterAffinity.excludeClusters | toYaml | nindent 44 }}
    {{- end }}
  {{- end }}
  replicaScheduling:
    replicaSchedulingType: {{ default .Values.broker.multicluster.replicaScheduling.replicaSchedulingType "Divided" | quote }}
    replicaDivisionPreference: {{ default .Values.broker.multicluster.replicaScheduling.replicaDivisionPreference "Weighted" | quote }}
    {{- if and .Values.broker.multicluster.replicaScheduling.weightPreference.staticWeightList (eq .Values.broker.multicluster.replicaScheduling.replicaDivisionPreference "Weighted" ) }}
    weightPreference:
      staticWeightList:
        {{- toYaml .Values.broker.multicluster.replicaScheduling.weightPreference.staticWeightList | nindent 8 }}
    {{- end }}
{{- end -}}
{{- end }}

{{/*
Define broker multicluster resource placement
*/}}
{{- define "pulsar.broker.multicluster.resource.placement" -}}
{{- if .Values.broker.multicluster.enabled -}}
placement:
  {{- if .Values.broker.multicluster.clusterAffinity }}
  clusterAffinity:
    {{- if .Values.broker.multicluster.clusterAffinity.clusters }}
    clusterNames:
    {{ .Values.broker.multicluster.clusterAffinity.clusters | toYaml | nindent 4 }}
    {{- end }}
    {{- if .Values.broker.multicluster.clusterAffinity.excludeClusters }}
    excludeClusters:
    {{ .Values.broker.multicluster.clusterAffinity.excludeClusters | toYaml | nindent 44 }}
    {{- end }}
  {{- end }}
{{- end -}}
{{- end }}

{{/*
Define the service url in Multicluster case
*/}}
{{- define "pulsar.broker.multicluster.service.url" -}}
{{- if and .Values.tls.enabled .Values.tls.broker.enabled -}}
pulsar+ssl://{{ template "pulsar.broker.service" . }}-headless.{{ template "pulsar.namespace" . }}.svc.clusterset.local:{{ .Values.broker.ports.pulsarssl }}
{{- else -}}
pulsar://{{ template "pulsar.broker.service" . }}-headless.{{ template "pulsar.namespace" . }}.svc.clusterset.local:{{ .Values.broker.ports.pulsar }}
{{- end -}}
{{- end -}}

{{/*
Define broker multicluster service access type
*/}}
{{- define "pulsar.broker.multicluster.serviceAccessType" -}}
{{- if .Values.broker.multicluster.enabled -}}
{{- if .Values.broker.multicluster.serviceAccessType }}
serviceAccessType: {{ .Values.broker.multicluster.serviceAccessType | quote }}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Define the internal web service url in Multicluster case
*/}}
{{- define "pulsar.web.multicluster.internal.service.url" -}}
{{- $host := printf "%s-headless.%s.svc.clusterset.local" (include "pulsar.broker.service" .) (include "pulsar.namespace" .) -}}
{{- $httpUrl := printf "http://%s:%s" $host (.Values.broker.ports.http | toString) -}}
{{- $httpUrl -}}
{{- end -}}
