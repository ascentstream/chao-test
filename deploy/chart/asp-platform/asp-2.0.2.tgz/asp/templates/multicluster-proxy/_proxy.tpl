{{/*
Define proxy multicluster enabled
*/}}
{{- define "pulsar.proxy.multicluster.enabled" -}}
{{- if .Values.proxy.multicluster.enabled -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Define proxy multicluster replicas placement
*/}}
{{- define "pulsar.proxy.multicluster.replicas.placement" -}}
{{- if .Values.proxy.multicluster.enabled -}}
placement:
  {{- if .Values.proxy.multicluster.clusterAffinity }}
  clusterAffinity:
    {{- if .Values.proxy.multicluster.clusterAffinity.clusters }}
    clusterNames:
    {{ .Values.proxy.multicluster.clusterAffinity.clusters | toYaml | nindent 4 }}
    {{- end }}
    {{- if .Values.proxy.multicluster.clusterAffinity.excludeClusters }}
    excludeClusters:
    {{ .Values.proxy.multicluster.clusterAffinity.excludeClusters | toYaml | nindent 44 }}
    {{- end }}
  {{- end }}
  replicaScheduling:
    replicaSchedulingType: {{ default .Values.proxy.multicluster.replicaScheduling.replicaSchedulingType "Divided" | quote }}
    replicaDivisionPreference: {{ default .Values.proxy.multicluster.replicaScheduling.replicaDivisionPreference "Weighted" | quote }}
    {{- if and .Values.proxy.multicluster.replicaScheduling.weightPreference.staticWeightList (eq .Values.proxy.multicluster.replicaScheduling.replicaDivisionPreference "Weighted" ) }}
    weightPreference:
      staticWeightList:
        {{- toYaml .Values.proxy.multicluster.replicaScheduling.weightPreference.staticWeightList | nindent 8 }}
    {{- end }}
{{- end -}}
{{- end }}

{{/*
Define proxy multicluster resource placement
*/}}
{{- define "pulsar.proxy.multicluster.resource.placement" -}}
{{- if .Values.proxy.multicluster.enabled -}}
placement:
  {{- if .Values.proxy.multicluster.clusterAffinity }}
  clusterAffinity:
    {{- if .Values.proxy.multicluster.clusterAffinity.clusters }}
    clusterNames:
    {{ .Values.proxy.multicluster.clusterAffinity.clusters | toYaml | nindent 4 }}
    {{- end }}
    {{- if .Values.proxy.multicluster.clusterAffinity.excludeClusters }}
    excludeClusters:
    {{ .Values.proxy.multicluster.clusterAffinity.excludeClusters | toYaml | nindent 44 }}
    {{- end }}
  {{- end }}
{{- end -}}
{{- end }}

{{/*
Pulsar Broker Service Address in Multicluster case
*/}}
{{- define "pulsar.proxy.multicluster.broker.service.address" -}}
{{- if .Values.proxy.multicluster.brokerServiceAddress -}}
{{- .Values.proxy.multicluster.brokerServiceAddress -}}
{{- else -}}
{{ template "pulsar.fullname" . }}-{{ .Values.broker.component }}.{{ template "pulsar.namespace" . }}.svc
{{- end -}}
{{- end -}}

{{/*
Define proxy multicluster service access type
*/}}
{{- define "pulsar.proxy.multicluster.serviceAccessType" -}}
{{- if .Values.proxy.multicluster.enabled -}}
{{- if .Values.proxy.multicluster.serviceAccessType }}
serviceAccessType: {{ .Values.proxy.multicluster.serviceAccessType | quote }}
{{- end -}}
{{- end -}}
{{- end -}}
