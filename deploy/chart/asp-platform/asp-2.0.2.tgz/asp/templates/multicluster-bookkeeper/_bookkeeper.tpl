{{/*
Define bookkeeper multicluster enabled
*/}}
{{- define "pulsar.bookkeeper.multicluster.enabled" -}}
{{- if .Values.bookkeeper.multicluster.enabled -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Define bookkeeper multicluster replicas placement
*/}}
{{- define "pulsar.bookkeeper.multicluster.replicas.placement" -}}
{{- if .Values.bookkeeper.multicluster.enabled -}}
placement:
  {{- if .Values.bookkeeper.multicluster.clusterAffinity }}
  clusterAffinity:
    {{- if .Values.bookkeeper.multicluster.clusterAffinity.clusters }}
    clusterNames:
    {{ .Values.bookkeeper.multicluster.clusterAffinity.clusters | toYaml | nindent 4 }}
    {{- end }}
    {{- if .Values.bookkeeper.multicluster.clusterAffinity.excludeClusters }}
    excludeClusters:
    {{ .Values.bookkeeper.multicluster.clusterAffinity.excludeClusters | toYaml | nindent 44 }}
    {{- end }}
  {{- end }}
  replicaScheduling:
    replicaSchedulingType: {{ default .Values.bookkeeper.multicluster.replicaScheduling.replicaSchedulingType "Divided" | quote }}
    replicaDivisionPreference: {{ default .Values.bookkeeper.multicluster.replicaScheduling.replicaDivisionPreference "Weighted" | quote }}
    {{- if and .Values.bookkeeper.multicluster.replicaScheduling.weightPreference.staticWeightList (eq .Values.bookkeeper.multicluster.replicaScheduling.replicaDivisionPreference "Weighted" ) }}
    weightPreference:
      staticWeightList:
        {{- toYaml .Values.bookkeeper.multicluster.replicaScheduling.weightPreference.staticWeightList | nindent 8 }}
    {{- end }}
{{- end -}}
{{- end }}

{{/*
Define bookkeeper multicluster service access type
*/}}
{{- define "pulsar.bookkeeper.multicluster.serviceAccessType" -}}
{{- if .Values.bookkeeper.multicluster.enabled -}}
{{- if .Values.bookkeeper.multicluster.serviceAccessType }}
serviceAccessType: {{ .Values.bookkeeper.multicluster.serviceAccessType | quote }}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Define bookkeeper multicluster resource placement
*/}}
{{- define "pulsar.bookkeeper.multicluster.resource.placement" -}}
{{- if .Values.bookkeeper.multicluster.enabled -}}
placement:
  {{- if .Values.bookkeeper.multicluster.clusterAffinity }}
  clusterAffinity:
    {{- if .Values.bookkeeper.multicluster.clusterAffinity.clusters }}
    clusterNames:
    {{ .Values.bookkeeper.multicluster.clusterAffinity.clusters | toYaml | nindent 4 }}
    {{- end }}
    {{- if .Values.bookkeeper.multicluster.clusterAffinity.excludeClusters }}
    excludeClusters:
    {{ .Values.bookkeeper.multicluster.clusterAffinity.excludeClusters | toYaml | nindent 44 }}
    {{- end }}
  {{- end }}
{{- end -}}
{{- end }}
