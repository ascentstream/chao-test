{{/*
Define pulsar detector multicluster replicas placement
*/}}
{{- define "pulsar.detector.multicluster.replicas.placement" -}}
{{- if .Values.pulsar_detector.multicluster.enabled -}}
placement:
  {{- if .Values.pulsar_detector.multicluster.clusterAffinity }}
  clusterAffinity:
    {{- if .Values.pulsar_detector.multicluster.clusterAffinity.clusters }}
    clusterNames:
    {{ .Values.pulsar_detector.multicluster.clusterAffinity.clusters | toYaml | nindent 4 }}
    {{- end }}
    {{- if .Values.pulsar_detector.multicluster.clusterAffinity.excludeClusters }}
    excludeClusters:
    {{ .Values.pulsar_detector.multicluster.clusterAffinity.excludeClusters | toYaml | nindent 44 }}
    {{- end }}
  {{- end }}
  replicaScheduling:
    replicaSchedulingType: "Duplicated"
{{- end -}}
{{- end }}

{{/*Define pulsar detector service url in Multicluster case, the TCP port*/}}
{{- define "pulsar.detector.multicluster.serviceUrl" -}}
{{- if .Values.pulsar_detector.multicluster.serviceUrl -}}
{{ .Values.pulsar_detector.multicluster.serviceUrl -}}
{{- else -}}
{{- if and .Values.tls.enabled .Values.tls.broker.enabled -}}
pulsar+ssl://{{ template "pulsar.detector.multicluster.pulsarServiceName" . }}.svc:{{ .Values.broker.ports.pulsarssl }}
{{- else -}}
pulsar://{{ template "pulsar.detector.multicluster.pulsarServiceName" . }}.svc:{{ .Values.broker.ports.pulsar }}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*Define pulsar detector webservice url in Multicluster case, the admin API*/}}
{{- define "pulsar.detector.multicluster.webServiceUrl" -}}
{{- if .Values.pulsar_detector.multicluster.webServiceUrl -}}
{{ .Values.pulsar_detector.multicluster.webServiceUrl -}}
{{- else -}}
{{- if and .Values.tls.enabled .Values.tls.broker.enabled -}}
https://{{ template "pulsar.detector.multicluster.pulsarServiceName" . }}.svc:{{ .Values.broker.ports.https }}
{{- else -}}
http://{{ template "pulsar.detector.multicluster.pulsarServiceName" . }}.svc:{{ .Values.broker.ports.http }}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*Define pulsar broker svc name in Multicluster case*/}}
{{- define "pulsar.detector.multicluster.pulsarServiceName" -}}
{{- if .Values.pulsar_detector.multicluster.pulsarServiceName -}}
{{ .Values.pulsar_detector.multicluster.pulsarServiceName -}}
{{- else -}}
{{ template "pulsar.fullname" . }}-{{ .Values.broker.component }}.{{ template "pulsar.namespace" . }}
{{- end -}}
{{- end -}}