{{/*
Define the pulsar kafkaproxy service
*/}}
{{- define "pulsar.kafkaproxy.service" -}}
{{ template "pulsar.fullname" . }}-{{ .Values.kafkaproxy.component }}
{{- end }}

{{/*
Define the service url
*/}}
{{- define "pulsar.kafkaproxy.service.url" -}}
{{ template "pulsar.kafkaproxy.service" . }}.{{ template "pulsar.namespace" . }}.svc.cluster.local
{{- end -}}

{{/*
Define the hostname
*/}}
{{- define "pulsar.kafkaproxy.hostname" -}}
${HOSTNAME}.{{ template "pulsar.kafkaproxy.service" . }}.{{ template "pulsar.namespace" . }}.svc.cluster.local
{{- end -}}

{{/*Define kafkaproxy pod name*/}}
{{- define "pulsar.kafkaproxy.podName" -}}
{{- print "kafka-proxy" -}}
{{- end -}}

{{/*Define kafkaproxy datadog annotation*/}}
{{- define "pulsar.kafkaproxy.datadog.annotation" -}}
{{- if .Values.datadog.components.kafkaproxy.enabled }}
{{- if eq (.Values.datadog.components.kafkaproxy.checkType | default "openmetrics") "openmetrics" }}
ad.datadoghq.com/{{ template "pulsar.kafkaproxy.podName" . }}.check_names: |
  ["openmetrics"]
ad.datadoghq.com/{{ template "pulsar.kafkaproxy.podName" . }}.init_configs: |
  [{}]
ad.datadoghq.com/{{ template "pulsar.kafkaproxy.podName" . }}.instances: |
  [
    {
      "prometheus_url": "http://%%host%%:{{ .Values.kafkaproxy.ports.health }}/metrics",
      {{ if .Values.datadog.namespace -}}
      "namespace": "{{ .Values.datadog.namespace }}",
      {{ else -}}
      "namespace": "{{ template "pulsar.namespace" . }}",
      {{ end -}}
      "metrics": {{ .Values.datadog.components.kafkaproxy.metrics }},
      "health_service_check": true,
      "prometheus_timeout": 1000,
      "max_returned_metrics": 1000000,
      "tags": [
        "kafka-proxy: {{ template "pulsar.fullname" . }}-{{ .Values.kafkaproxy.component }}"
      ]
    }
  ]
{{- else if eq (.Values.datadog.components.kafkaproxy.checkType | default "openmetrics") "native" }}
ad.datadoghq.com/{{ template "pulsar.kafkaproxy.podName" . }}.check_names: |
  ["kafka"]
ad.datadoghq.com/{{ template "pulsar.kafkaproxy.podName" . }}.init_configs: |
  [{}]
ad.datadoghq.com/{{ template "pulsar.kafkaproxy.podName" . }}.instances: |
  [
    {
      "openmetrics_endpoint": "http://%%host%%:{{ .Values.kafkaproxy.ports.health }}/metrics",
      "enable_health_service_check": true,
      "timeout": 300,
      "tags": [
        "kafka-proxy: {{ template "pulsar.fullname" . }}-{{ .Values.kafkaproxy.component }}"
      ]
    }
  ]
{{- end }}
{{- end }}
{{- end }}

{{/*Define kafkaproxy service account*/}}
{{- define "pulsar.kafkaproxy.serviceAccount" -}}
{{- if .Values.kafkaproxy.serviceAccount.create -}}
    {{- if .Values.kafkaproxy.serviceAccount.name -}}
{{ .Values.kafkaproxy.serviceAccount.name }}
    {{- else -}}
{{ template "pulsar.fullname" . }}-{{ .Values.kafkaproxy.component }}-acct
    {{- end -}}
{{- else -}}
{{ .Values.kafkaproxy.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
Define KafkaProxy multicluster enabled status
*/}}
{{- define "pulsar.kafkaproxy.multicluster.enabled" -}}
{{- if and .Values.kafkaproxy.multicluster.enabled (not .Values.kafkaproxy.multicluster.brokerServiceAddress) -}}
{{- print "true" -}}
{{- else -}}
{{- print "false" -}}
{{- end -}}
{{- end -}}