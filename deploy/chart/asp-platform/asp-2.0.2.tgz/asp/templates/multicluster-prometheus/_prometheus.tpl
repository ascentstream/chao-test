{{/*
Define prometheus multicluster enabled
*/}}
{{- define "pulsar.prometheus.multicluster.enabled" -}}
{{- if .Values.prometheus.multicluster.enabled -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Define prometheus multicluster replicas placement
*/}}
{{- define "pulsar.prometheus.multicluster.replicas.placement" -}}
{{- if .Values.prometheus.multicluster.enabled -}}
placement:
  {{- if .Values.prometheus.multicluster.clusterAffinity }}
  clusterAffinity:
    {{- if .Values.prometheus.multicluster.clusterAffinity.clusters }}
    clusterNames:
    {{ .Values.prometheus.multicluster.clusterAffinity.clusters | toYaml | nindent 4 }}
    {{- end }}
    {{- if .Values.prometheus.multicluster.clusterAffinity.excludeClusters }}
    excludeClusters:
    {{ .Values.prometheus.multicluster.clusterAffinity.excludeClusters | toYaml | nindent 44 }}
    {{- end }}
  {{- end }}
  replicaScheduling:
    replicaSchedulingType: "Duplicated"
{{- end -}}
{{- end }}

{{/*
Define prometheus multicluster resource placement
*/}}
{{- define "pulsar.prometheus.multicluster.resource.placement" -}}
{{- if .Values.prometheus.multicluster.enabled -}}
placement:
  {{- if .Values.prometheus.multicluster.clusterAffinity }}
  clusterAffinity:
    {{- if .Values.prometheus.multicluster.clusterAffinity.clusters }}
    clusterNames:
    {{ .Values.prometheus.multicluster.clusterAffinity.clusters | toYaml | nindent 4 }}
    {{- end }}
    {{- if .Values.prometheus.multicluster.clusterAffinity.excludeClusters }}
    excludeClusters:
    {{ .Values.prometheus.multicluster.clusterAffinity.excludeClusters | toYaml | nindent 44 }}
    {{- end }}
  {{- end }}
{{- end -}}
{{- end }}
