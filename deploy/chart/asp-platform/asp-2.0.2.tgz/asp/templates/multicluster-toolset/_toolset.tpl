{{/*
Define toolset multicluster replicas placement
*/}}
{{- define "pulsar.toolset.multicluster.replicas.placement" -}}
{{- if .Values.toolset.multicluster.enabled -}}
placement:
  {{- if .Values.toolset.multicluster.clusterAffinity }}
  clusterAffinity:
    {{- if .Values.toolset.multicluster.clusterAffinity.clusters }}
    clusterNames:
    {{ .Values.toolset.multicluster.clusterAffinity.clusters | toYaml | nindent 4 }}
    {{- end }}
    {{- if .Values.toolset.multicluster.clusterAffinity.excludeClusters }}
    excludeClusters:
    {{ .Values.toolset.multicluster.clusterAffinity.excludeClusters | toYaml | nindent 44 }}
    {{- end }}
  {{- end }}
  replicaScheduling:
    replicaSchedulingType: "Duplicated"
{{- end -}}
{{- end }}
