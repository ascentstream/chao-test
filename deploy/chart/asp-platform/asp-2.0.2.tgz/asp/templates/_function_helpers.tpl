{{/* vim: set filetype=mustache: */}}

{{/*
Define function runner images
*/}}
{{- define "pulsar.functionRunnerImages" -}}
{{- $runnerImages := .Values.broker.functionmesh.configData.functionsWorkerServiceCustomConfigs.functionRunnerImages }}
functionRunnerImages:
  go: "{{ $runnerImages.go.repository }}:{{ default .Values.global.aspImageTag $runnerImages.go.tag }}"
  java: "{{ $runnerImages.java.repository }}:{{ default .Values.global.aspImageTag $runnerImages.java.tag }}"
  python: "{{ $runnerImages.python.repository }}:{{ default .Values.global.aspImageTag $runnerImages.python.tag }}"
{{- end }} 