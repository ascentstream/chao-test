{{/*
Define zookeeper multicluster enabled
*/}}
{{- define "pulsar.zookeeper.multicluster.enabled" -}}
{{- if .Values.zookeeper.multicluster.enabled -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Define zookeeper multicluster service access type
*/}}
{{- define "pulsar.zookeeper.multicluster.serviceAccessType" -}}
{{- if .Values.zookeeper.multicluster.enabled -}}
{{- if .Values.zookeeper.multicluster.serviceAccessType }}
serviceAccessType: {{ .Values.zookeeper.multicluster.serviceAccessType | quote }}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Define zookeeper multicluster replicas placement
*/}}
{{- define "pulsar.zookeeper.multicluster.replicas.placement" -}}
{{- if .Values.zookeeper.multicluster.enabled -}}
placement:
  {{- if .Values.zookeeper.multicluster.clusterAffinity }}
  clusterAffinity:
    {{- if .Values.zookeeper.multicluster.clusterAffinity.clusters }}
    clusterNames:
    {{ .Values.zookeeper.multicluster.clusterAffinity.clusters | toYaml | nindent 4 }}
    {{- end }}
    {{- if .Values.zookeeper.multicluster.clusterAffinity.excludeClusters }}
    excludeClusters:
    {{ .Values.zookeeper.multicluster.clusterAffinity.excludeClusters | toYaml | nindent 44 }}
    {{- end }}
  {{- end }}
  replicaScheduling:
    replicaSchedulingType: {{ default .Values.zookeeper.multicluster.replicaScheduling.replicaSchedulingType "Divided" | quote }}
    replicaDivisionPreference: {{ default .Values.zookeeper.multicluster.replicaScheduling.replicaDivisionPreference "Weighted" | quote }}
    {{- if and .Values.zookeeper.multicluster.replicaScheduling.weightPreference.staticWeightList (eq .Values.zookeeper.multicluster.replicaScheduling.replicaDivisionPreference "Weighted" ) }}
    weightPreference:
      staticWeightList:
        {{- toYaml .Values.zookeeper.multicluster.replicaScheduling.weightPreference.staticWeightList | nindent 8 }}
    {{- end }}
{{- end -}}
{{- end }}

{{/*
Define zookeeper multicluster resource placement
*/}}
{{- define "pulsar.zookeeper.multicluster.resource.placement" -}}
{{- if .Values.zookeeper.multicluster.enabled -}}
placement:
  {{- if .Values.zookeeper.multicluster.clusterAffinity }}
  clusterAffinity:
    {{- if .Values.zookeeper.multicluster.clusterAffinity.clusters }}
    clusterNames:
    {{ .Values.zookeeper.multicluster.clusterAffinity.clusters | toYaml | nindent 4 }}
    {{- end }}
    {{- if .Values.zookeeper.multicluster.clusterAffinity.excludeClusters }}
    excludeClusters:
    {{ .Values.zookeeper.multicluster.clusterAffinity.excludeClusters | toYaml | nindent 44 }}
    {{- end }}
  {{- end }}
{{- end -}}
{{- end }}

{{/*
Define the pulsar zookeeper in Multicluster case
*/}}
{{- define "pulsar.zookeeper.multicluster.service" -}}
{{ template "pulsar.fullname" . }}-{{ .Values.zookeeper.component }}.{{ template "pulsar.namespace" . }}.svc.clusterset.local
{{- end }}

{{/*
Define the pulsar zookeeper in Multicluster case
*/}}
{{- define "pulsar.zookeeper.multicluster.connect" -}}
{{$zk := .Values.pulsar_metadata.userProvidedZookeepers}}
{{- if and $zk (eq .Values.zookeeper.multicluster.serviceAccessType "ip") -}}
{{- $zk -}}
{{ else }}
{{- if not (and .Values.tls.enabled .Values.tls.zookeeper.enabled) -}}
{{ template "pulsar.zookeeper.multicluster.service" . }}:{{ .Values.zookeeper.ports.client }}
{{- end -}}
{{- if and .Values.tls.enabled .Values.tls.zookeeper.enabled -}}
{{ template "pulsar.zookeeper.multicluster.service" . }}:{{ .Values.zookeeper.ports.clientTls }}
{{- end -}}
{{- end -}}
{{- end -}}
