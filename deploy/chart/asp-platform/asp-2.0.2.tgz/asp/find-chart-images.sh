#!/bin/bash

# Script to find all Docker images used in a Helm chart
# Outputs a simple bulleted list of images in the format "- image:tag"

set -e

# Define the directory to search
CHART_DIR="$(pwd)"

# Create a temporary file for collecting image references
TEMP_FILE=$(mktemp)

# Check if global.aspImageTag is set in values.yaml
GLOBAL_TAG=""
if [ -f "$CHART_DIR/values.yaml" ]; then
    GLOBAL_TAG=$(grep "aspImageTag:" "$CHART_DIR/values.yaml" | head -1 | sed 's/.*aspImageTag:[[:space:]]*//g' | sed 's/"//g' | sed "s/'//g" | sed 's/^[[:space:]]*//g')
    if [ -z "$GLOBAL_TAG" ]; then
        # Try to find the tag in the command line args, used with --set
        HELM_ARGS=$(ps -ef | grep "helm install" | grep "global.aspImageTag" || echo "")
        if [ -n "$HELM_ARGS" ]; then
            GLOBAL_TAG=$(echo "$HELM_ARGS" | grep -o "global.aspImageTag=[^ ]*" | cut -d= -f2)
        fi
    fi
fi

# Find image references in values.yaml (direct image: entries)
if [ -f "$CHART_DIR/values.yaml" ]; then
    # Direct image entries (image: docker.io/org/image:tag)
    grep "image:" "$CHART_DIR/values.yaml" | grep -v "#" | grep -v "imagePullPolicy\|imageTag" | sed 's/.*image:[[:space:]]*//g' | sed 's/"//g' | sed "s/'//g" | sed 's/^[[:space:]]*//g' >> "$TEMP_FILE" || true
    
    # Repository and tag combinations
    # First, extract repository lines with their line numbers
    grep -n "repository:" "$CHART_DIR/values.yaml" | grep -v "#" | while read -r repo_line; do
        line_num=$(echo "$repo_line" | cut -d':' -f1)
        repo=$(echo "$repo_line" | sed 's/.*repository:[[:space:]]*//g' | sed 's/"//g' | sed "s/'//g" | sed 's/^[[:space:]]*//g')
        
        # Look for tag in the next few lines
        tag=$(tail -n +$((line_num+1)) "$CHART_DIR/values.yaml" | head -n 3 | grep "tag:" | sed 's/.*tag:[[:space:]]*//g' | sed 's/"//g' | sed "s/'//g" | sed 's/^[[:space:]]*//g')
        
        # Special handling for ascentstream/as-platform
        if [ "$repo" = "ascentstream/as-platform" ] && [ -z "$tag" -o "$tag" = "#" ]; then
            # If global tag is found, use it instead of 'latest'
            if [ -n "$GLOBAL_TAG" ]; then
                echo "$repo:$GLOBAL_TAG" >> "$TEMP_FILE"
            else
                echo "$repo:latest (uses aspImageTag if set)" >> "$TEMP_FILE"
            fi
        # If tag found, combine with repo
        elif [ -n "$tag" ]; then
            # Skip if tag is just a comment
            if [[ ! "$tag" =~ ^#.* ]]; then
                echo "$repo:$tag" >> "$TEMP_FILE"
            fi
        else
            echo "$repo:latest" >> "$TEMP_FILE"
        fi
    done
fi

# Extract images directly defined in values.yaml
if [ -f "$CHART_DIR/values.yaml" ]; then
    # Get all sections with direct image: definitions
    grep -A1 "image:" "$CHART_DIR/values.yaml" | grep -v "#" | grep -v "\-\-" | \
    sed 's/^[[:space:]]*//g' | grep -v "^image:" | grep -v "^$" >> "$TEMP_FILE" || true
fi

# Search for image references in template files
find "$CHART_DIR/templates" -type f -name "*.yaml" -o -name "*.yml" 2>/dev/null | while read -r file; do
    # Extract image references from templates (without template syntax)
    grep "image:" "$file" 2>/dev/null | grep -v "#" | sed 's/.*image:[[:space:]]*//g' | \
    sed 's/"//g' | sed "s/'//g" | sed 's/^[[:space:]]*//g' | \
    grep -v "{{.*}}" >> "$TEMP_FILE" || true
done

# Some charts define images with repository and tag separately in templates
# Check template directory for these types of image references
if [ -d "$CHART_DIR/templates" ]; then
    # Get a list of all potential image references from .Values.xxx.repository
    grep -r "\.Values.*\.repository" --include="*.yaml" --include="*.tpl" "$CHART_DIR/templates" 2>/dev/null | \
    sed 's/.*\.Values\.\([a-zA-Z0-9_]*\)\.repository.*/\1/g' | sort | uniq | while read -r component; do
        # For each identified component, check if it exists in values.yaml
        if [ -f "$CHART_DIR/values.yaml" ]; then
            repo=$(grep -A1 "${component}:" "$CHART_DIR/values.yaml" | grep "repository:" | \
                  sed 's/.*repository:[[:space:]]*//g' | sed 's/"//g' | sed "s/'//g" | sed 's/^[[:space:]]*//g')
            tag=$(grep -A3 "${component}:" "$CHART_DIR/values.yaml" | grep "tag:" | \
                 sed 's/.*tag:[[:space:]]*//g' | sed 's/"//g' | sed "s/'//g" | sed 's/^[[:space:]]*//g')
            
            # Special handling for ascentstream/as-platform
            if [ "$repo" = "ascentstream/as-platform" ] && [ -z "$tag" -o "$tag" = "#" ]; then
                # If global tag is found, use it instead of 'latest'
                if [ -n "$GLOBAL_TAG" ]; then
                    echo "$repo:$GLOBAL_TAG" >> "$TEMP_FILE"
                else
                    echo "$repo:latest (uses aspImageTag if set)" >> "$TEMP_FILE"
                fi
            elif [ -n "$repo" ] && [ -n "$tag" ]; then
                echo "$repo:$tag" >> "$TEMP_FILE"
            elif [ -n "$repo" ]; then
                echo "$repo:latest" >> "$TEMP_FILE"
            fi
        fi
    done
fi

# Output the unique image references as a bulleted list
sort "$TEMP_FILE" | uniq | grep -v "^[[:space:]]*$" | grep -v "|" | grep -v "{" | grep -v "}" | \
grep -v "This will be overridden" | while read -r line; do
    if [ -n "$line" ]; then
        echo "- $line"
    fi
done

# Clean up
rm -f "$TEMP_FILE"

# Make the script executable
chmod +x "$0" 