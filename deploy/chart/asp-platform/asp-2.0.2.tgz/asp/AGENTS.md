# Repository Guidelines

## Project Structure & Module Organization
The ASP Helm chart lives at the repository root. `Chart.yaml` defines chart metadata; bump `version` and `appVersion` together during releases. Default configuration is in `values.yaml`, with vendor overrides in `values-vke.yaml`. Feature toggles for CI live in `ci/` (Istio, monitoring, backup). Kubernetes manifests are grouped under `templates/` by component (for example `templates/broker`, `templates/function-worker`). Shared helpers sit in `templates/_helpers.tpl` and `_function_helpers.tpl`; extend those first to avoid copy-paste logic. Packaged configs are stored in `conf/`, while reference material resides in `docs/specs`.

## Build, Test, and Development Commands
- `helm dependency update .` refreshes chart dependencies before packaging.
- `helm lint .` validates schema and render rules; resolve warnings before pushing.
- `helm template asp . -f values.yaml` previews manifests; combine with `-f ci/enable-istio-values.yaml` or other overrides to test profiles.
- `helm package . -d target` generates the distributable tarball.
- `./find-chart-images.sh` enumerates container images to confirm registry availability ahead of a release.

## Coding Style & Naming Conventions
Use two-space indentation in YAML and keep keys lowercase with hyphenated words (e.g. `pulsar-coordinator`). Helm templates should rely on pipelines (`{{- with }}`, `{{- include }}`) and helpers namespaced as `asp.*`. Place new component templates in a dedicated subdirectory under `templates/` and mirror existing file naming (`deployment.yaml`, `service.yaml`). Surface user-facing defaults in `values.yaml` and reserve advanced toggles for `global.*` or component-specific sections.

## Testing Guidelines
Run `helm lint` and render templates with the default values plus any affected CI profile (e.g. `helm template asp . -f ci/disable-monitoring-values.yaml`). For breaking changes, capture the diff against a cluster with `helm diff upgrade asp . --values <file>` when accessible. Keep assertions inside helper templates or comments when logic becomes non-trivial so reviewers can follow intent.

## Commit & Pull Request Guidelines
Follow the prevailing conventional commit style (`feat:`, `fix:`, `chore:`) and mention impacted components (`feat: broker tls init`). PRs should include a summary, affected values, validation evidence (lint output or rendered snippets), and linked issues or release tickets. Attach screenshots only when altering dashboards (e.g. Grafana panels).

## Configuration Profiles & Release Tips
Document new configuration overlays inside `ci/` or `conf/` with inline comments and reference them in `docs/specs`. When bumping versions, update `Chart.yaml`, regenerate artifacts under `target/`, and validate image inventories through `./find-chart-images.sh`. Align `docs/specs` with chart behavior before tagging a release.
