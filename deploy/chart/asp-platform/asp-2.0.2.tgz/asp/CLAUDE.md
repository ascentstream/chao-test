# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

ASP (AscentStream Platform) Chart is a Helm chart for deploying AscentStream Platform, which is built on Apache Pulsar. The chart currently uses version `0.9.2` with default Pulsar version `2.10.7.5`. Chart maintains Chinese documentation at [wolai.com](https://www.wolai.com/ascentstream/kWfPJveE2148P7A8jgo1sC).

## Common Commands

### Helm Chart Operations
```bash
# Install the chart
helm install asp . --namespace <namespace>

# Install with custom image tag
helm install asp . --set global.aspImageTag="x.x.x.x" --namespace <namespace>

# Upgrade the chart
helm upgrade asp . --namespace <namespace>

# Uninstall the chart
helm uninstall asp --namespace <namespace>

# Lint the chart
helm lint .

# Template the chart (dry-run)
helm template asp . --namespace <namespace>

# Package the chart
helm package .
```

### Chart Development & Validation
```bash
# Find all Docker images used in the chart
./find-chart-images.sh

# Validate templates against specific values file
helm template asp . -f ci/disable-monitoring-values.yaml --debug

# Check chart values schema
helm show values .
```

### Testing Different Configurations
The `ci/` directory contains different values files for testing:
- `ci/disable-monitoring-values.yaml` - Disables all monitoring components
- `ci/enable-istio-values.yaml` - Enables Istio service mesh
- `ci/enable-zookeeper-backup.yaml` - Enables ZooKeeper backup functionality

Use with: `helm install asp . -f ci/disable-monitoring-values.yaml`

### Dependency Management
```bash
# Update chart dependencies
helm dependency update

# Download dependencies
helm dependency build
```

## Architecture Overview

### Core Components Structure
The chart is organized around these main AscentStream/Pulsar components:
- **Vault**: Secret management (optional)
- **ZooKeeper**: Metadata storage and coordination
- **BookKeeper**: Log storage with auto-recovery
- **Broker**: Message broker with function worker capabilities
- **Proxy**: Protocol gateway and load balancer
- **Toolset**: Administrative tools and utilities
- **AscentStream Console**: Management UI

### Multi-cluster Support
The chart includes multi-cluster templates in `templates/multicluster-*` directories for deploying across multiple Kubernetes clusters.

### Template Organization
- `templates/_helpers.tpl`: Common template functions and variables
- `templates/_function_helpers.tpl`: Function-specific template helpers
- `templates/*/`: Component-specific templates organized by service
- `templates/multicluster-*/`: Multi-cluster deployment templates
- Component templates follow pattern: `<component>-<resource-type>.yaml`

### Configuration Patterns
- Global settings in `values.yaml` under `global:` section
- Component-specific settings under component name
- Image configuration centralized with `global.aspImageTag`
- Persistence controlled globally with `volumes.persistence`
- Anti-affinity rules controlled globally with `affinity.*`

### Log4j2 Configuration Override
The chart supports dynamic log4j2 configuration override through `values.yaml`, allowing users to customize logging settings without modifying static configuration files.

**Configuration Priority**:
1. **Values configuration** (highest priority) - Custom log4j2 configuration in `values.yaml`
2. **Static files** (fallback) - Default log4j2 configuration files in `conf/` directory

**Supported Components and Configuration Paths**:
- **BookKeeper**: `bookkeeper.custom.log4j2.yaml`
- **AutoRecovery**: `autorecovery.configData.log4j2.yaml`
- **ZooKeeper**: `zookeeper.custom.log4j2.yaml`
- **Toolset**: `toolset.configData.log4j2.yaml`

**Usage Example**:
```yaml
# Override BookKeeper log4j2 configuration
bookkeeper:
  custom:
    log4j2.yaml: |
      Configuration:
        status: INFO
        monitorInterval: 30
        name: CustomBookKeeperConfig
        Appenders:
          Console:
            name: "stdout"
            target: "SYSTEM_OUT"
            PatternLayout:
              pattern: "%d{HH:mm:ss.SSS} [%t] %-5level %logger{36} - %msg%n"
        Loggers:
          Logger:
            - name: "org.apache.bookkeeper"
              level: "DEBUG"
              additivity: false
              AppenderRef:
                - ref: "stdout"
          Root:
            level: "INFO"
            AppenderRef:
              - ref: "stdout"

# Override ZooKeeper log4j2 configuration
zookeeper:
  custom:
    log4j2.yaml: |
      Configuration:
        status: WARN
        name: CustomZooKeeperConfig
        # ... your custom configuration
```

**How it Works**:
- When custom log4j2 configuration is provided in `values.yaml`, the chart uses it instead of the static configuration files
- If no custom configuration is provided, the chart falls back to the default static files in `conf/` directory
- The override mechanism prevents configuration duplication and ensures clean deployments

### Key Configuration Sections
- `components.*`: Enable/disable individual components
- `monitoring.*`: Control monitoring stack (Prometheus, Grafana, Loki, etc.)
- `istio.*`: Service mesh configuration
- `tls.*`: TLS/SSL certificate management
- `multicluster.*`: Cross-cluster deployment settings

### Monitoring Stack
Built-in monitoring includes:
- Prometheus for metrics collection
- Grafana for visualization  
- Loki for log aggregation (via loki-stack dependency)
- Node Exporter for system metrics
- AlertManager for alerting

### Image Strategy
The chart supports both AscentStream Platform images (`ascentstream/platform*`) and standard Apache Pulsar images, with automatic path detection in helper templates.

## Development Notes

- Chart follows Apache Software Foundation licensing
- Uses Helm v2 API (`apiVersion: v2`)
- Templates use Kubernetes 1.16+ resource versions
- Supports both traditional and Istio-enabled deployments
- Configuration validation through helper templates
- Persistent volumes configurable per-component or globally

### Helper Template Patterns
Key helper templates in `_helpers.tpl`:
- Image path resolution logic for both AscentStream and standard Pulsar images
- Component enable/disable logic
- Global configuration inheritance patterns
- TLS certificate management helpers

### File Structure Notes
- `conf/`: Static configuration files (log4j2.yaml) for each component, used as fallback when custom config not provided
- `docs/`: Contains issue/PR templates and specifications
- `target/`: Build artifacts directory (generated)
- `ci/`: Test values files for different deployment scenarios
