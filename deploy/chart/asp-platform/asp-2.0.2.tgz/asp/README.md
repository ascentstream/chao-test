# ASP(AcentStream Platform)-Chart

当前 chart 版本：`v2.0.0`

当前默认 pulsar 版本：`2.10.7.5`，支持可使用 `--set global.aspImageTag="x.x.x.x"` 的方式指定版本

当前最新分支：`branch-2.0`

文档请参考 -> [AS Platform Charts 部署文档](https://www.wolai.com/ascentstream/kWfPJveE2148P7A8jgo1sC)