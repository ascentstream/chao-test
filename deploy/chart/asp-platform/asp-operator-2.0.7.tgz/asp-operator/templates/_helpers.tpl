{{/*
Expand the name of the chart.
*/}}
{{- define "asp-operator.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "asp-operator.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Expand to the namespace asp-operator installs into.
*/}}
{{- define "asp-operator.namespace" -}}
{{- default .Release.Namespace .Values.namespace -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "asp-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
ASP Operator labels
*/}}
{{- define "asp-operator.labels" -}}
helm.sh/chart: {{ include "asp-operator.chart" . }}
{{ include "asp-operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: "asp-operator"
{{- end }}

{{/*
ASP Operator Selector labels
*/}}
{{- define "asp-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "asp-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: "asp-operator"
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "asp-operator.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "asp-operator.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
install platform.bookkeeper crd yaml file to tpl.
*/}}
{{- define "platform.bookkeeper.crd" -}}
{{- $files := .Files }}
{{ $files.Get "operator-crds/platform.ascentstream.com_bookkeepers.yaml" }}
{{- end -}}

{{/*
install multicluster.bookkeeper crd yaml file to tpl.
*/}}
{{- define "multicluster.bookkeeper.crd" -}}
{{- $files := .Files }}
{{ $files.Get "operator-crds/multicluster.ascentstream.com_multiclusterbookkeepers.yaml" }}
{{- end -}}

{{/*
install platform.broker crd yaml file to tpl.
*/}}
{{- define "platform.broker.crd" -}}
{{- $files := .Files }}
{{ $files.Get "operator-crds/platform.ascentstream.com_brokers.yaml" }}
{{- end -}}

{{/*
install multicluster.broker crd yaml file to tpl.
*/}}
{{- define "multicluster.broker.crd" -}}
{{- $files := .Files }}
{{ $files.Get "operator-crds/multicluster.ascentstream.com_multiclusterbrokers.yaml" }}
{{- end -}}

{{/*
install platform.proxy crd yaml file to tpl.
*/}}
{{- define "platform.proxy.crd" -}}
{{- $files := .Files }}
{{ $files.Get "operator-crds/platform.ascentstream.com_proxies.yaml" }}
{{- end -}}

{{/*
install platform.kafkaproxy crd yaml file to tpl.
*/}}
{{- define "platform.kafkaproxy.crd" -}}
{{- $files := .Files }}
{{ $files.Get "operator-crds/platform.ascentstream.com_kafkaproxies.yaml" }}
{{- end -}}

{{/*
install multicluster.proxy crd yaml file to tpl.
*/}}
{{- define "multicluster.proxy.crd" -}}
{{- $files := .Files }}
{{ $files.Get "operator-crds/multicluster.ascentstream.com_multiclusterproxies.yaml" }}
{{- end -}}


{{/*
install platform.zookeeper crd yaml file to tpl
*/}}
{{- define "platform.zookeeper.crd" -}}
{{- $files := .Files }}
{{ $files.Get "operator-crds/platform.ascentstream.com_zookeepers.yaml" }}
{{- end -}}

{{/*
install multicluster.zookeeper crd yaml file to tpl
*/}}
{{- define "multicluster.zookeeper.crd" -}}
{{- $files := .Files }}
{{ $files.Get "operator-crds/multicluster.ascentstream.com_multiclusterzookeepers.yaml" }}
{{- end -}}

{{/*
Expand to the namespace asp-operator-interpreter-webhook installs into.
*/}}
{{- define "interpreter-webhook.namespace" -}}
{{- default .Values.multicluster.interpreterWebhook.namespace "karmada-system" -}}
{{- end -}}

{{/*
ASP Operator interpreter webhook labels
*/}}
{{- define "interpreter-webhook.labels" -}}
helm.sh/chart: {{ include "asp-operator.chart" . }}
{{ include "interpreter-webhook.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: "asp-operator"
{{- end }}

{{/*
ASP Operator interpreter webhook Selector labels
*/}}
{{- define "interpreter-webhook.selectorLabels" -}}
app.kubernetes.io/name: {{ include "interpreter-webhook.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}-interpreter-webhook
app.kubernetes.io/component: "interpreter-webhook"
{{- end }}

{{/*
ASP Operator interpreter webhook fullname
*/}}
{{- define "interpreter-webhook.fullname" -}}
{{ include "asp-operator.fullname" . }}-interpreter-webhook
{{- end -}}

{{- define "interpreter-webhook.zookeeper.url" -}}
https://{{ template "interpreter-webhook.fullname" . }}.{{ template "interpreter-webhook.namespace" . }}.svc:{{ default .Values.multicluster.interpreterWebhook.service.port "443" }}/interpreter-zookeeper
{{- end -}}

{{- define "interpreter-webhook.bookkeeper.url" -}}
https://{{ template "interpreter-webhook.fullname" . }}.{{ template "interpreter-webhook.namespace" . }}.svc:{{ default .Values.multicluster.interpreterWebhook.service.port "443" }}/interpreter-bookkeeper
{{- end -}}

{{- define "interpreter-webhook.broker.url" -}}
https://{{ template "interpreter-webhook.fullname" . }}.{{ template "interpreter-webhook.namespace" . }}.svc:{{ default .Values.multicluster.interpreterWebhook.service.port "443" }}/interpreter-broker
{{- end -}}

{{- define "interpreter-webhook.proxy.url" -}}
https://{{ template "interpreter-webhook.fullname" . }}.{{ template "interpreter-webhook.namespace" . }}.svc:{{ default .Values.multicluster.interpreterWebhook.service.port "443" }}/interpreter-proxy
{{- end -}}

{{/*
Helper function to generate environment variables for multi-cluster configuration
*/}}
{{- define "asp-operator.multicluster.envs" -}}
- name: MULTI_CLUSTER_MODE_ENABLED
  value: "{{ .Values.multicluster.enabled | ternary "true" "false" }}"
- name: SYNC_ENDPOINT_SLICE
  value: "{{ .Values.multicluster.syncEndpointSlice | ternary "true" "false" }}"
{{- end -}}
